
var mode = 0;
var counter = 0;
let mic, fft;


function setup() {
    createCanvas(windowWidth, windowHeight);
    splash = new Splash();
    mic = new p5.AudioIn();
    mic.start();
    fft = new p5.FFT();
    fft.setInput(mic);

}

function draw() {
    counter = counter + 1;
    if (mode == 0 && mouseIsPressed == true) {
        mode = 1;
        splash.hide();
        drawSea();
        drawWaves(); // Light blue sky background
    }
    if (mode == 1 && counter > 60) {
        counter = 0;
        let spectrum = fft.analyze();
      
        if (spectrum[10]>100) {
          console.log(spectrum);
       drawCloud(random(windowWidth / 40, windowWidth), 
                      random(windowHeight / 40, windowHeight / 3),
                      random(100, 120), random(100, 150));
        }
    
}}

function drawWaves() {
    noFill();
    stroke(255); // White color for the waves
    strokeWeight(2);

    // Create smooth, undulating waves
    for (let y = 0; y < height; y += 20) {
        beginShape();
        for (let x = 0; x <= width; x += 20) {
            let angle = (frameCount * 0.2 + x) * 0.04; // Change multiplier for speed and frequency
            let sinValue = sin(angle) * 12; // Change amplitude for wave height
            vertex(x, height * 0.70 + y + sinValue);
        }
        endShape();
    }
}


function drawSea() {
    for (let y = 0; y < height; y++) {
        let seaColor = map(y, 0, height, 280, 188); // Gradient from light to darker blue
        fill(51, 204, seaColor);
        noStroke();
        rect(0, y, width, 1);
    }
}

function drawCloud(x, y, width, height) {
    noStroke();
    let layers = random(10, 40); // Number of layers to create the blur effect
    let alphaValue = random(80, 200); // Starting alpha value for the topmost layer

    // Draw each layer with decreasing size and alpha
    for (let i = layers; i > 0; i--) {
        let ratio = i / layers;
        fill(255, alphaValue * ratio); // Adjust alpha value for blur effect
        ellipse(x, y, width * ratio * 0.5, height * ratio * 0.5);
        ellipse(x - random(40, 60) * ratio, y, width * ratio * 0.6, height * ratio * 0.6);
        ellipse(x + random(30, 40) * ratio, y, width * ratio * 0.6, height * ratio * 0.6);
        ellipse(x - random(10, 30) * ratio, y - random(30, 40) * ratio, width * ratio * 0.7, height * ratio * 0.7);
        ellipse(x + random(10, 40) * ratio, y - random(30, 40) * ratio, width * ratio * 0.7, height * ratio * 0.7);
    }
}

